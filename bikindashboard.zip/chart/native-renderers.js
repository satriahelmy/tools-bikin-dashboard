/* Small SVG renderers for chart types that are not part of Chart.js core.
   Keeping these local avoids loading a plugin just to explain three chart
   patterns in the guide. Each renderer is deliberately data-driven and
   includes a title on every visual mark for screen-reader/browser inspection. */
(function () {
  const esc = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const number = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
  const text = (value, x, y, cls = '') => `<text x="${x}" y="${y}" class="native-chart-text ${cls}">${esc(value)}</text>`;

  function svg(inner, label) {
    return `<svg viewBox="0 0 960 340" role="img" aria-label="${esc(label)}" xmlns="http://www.w3.org/2000/svg">
      <style>
        .native-chart-text{font:500 13px 'Plus Jakarta Sans',Arial,sans-serif;fill:#475569}
        .native-chart-title{font-weight:600;fill:#0f172a}
        .native-chart-muted{font-size:11px;fill:#94a3b8}
        .native-chart-grid{stroke:#e2e8f0;stroke-width:1}
      </style>${inner}</svg>`;
  }

  function renderTreemap(chart, mount) {
    const labels = chart?.chartjs?.data?.labels || [];
    const dataset = chart?.chartjs?.data?.datasets?.[0] || {};
    const values = (dataset.data || []).map(number);
    if (labels.length < 2 || values.length !== labels.length) return false;

    const colors = Array.isArray(dataset.backgroundColor) ? dataset.backgroundColor : [];
    const total = values.reduce((sum, value) => sum + Math.max(0, value), 0) || 1;
    const left = 24, top = 22, width = 912, rowHeight = 126, gap = 5;
    const split = Math.ceil(labels.length / 2);
    let inner = '';
    [labels.slice(0, split), labels.slice(split)].forEach((rowLabels, rowIndex) => {
      const rowValues = values.slice(rowIndex ? split : 0, rowIndex ? labels.length : split);
      const rowTotal = rowValues.reduce((sum, value) => sum + Math.max(0, value), 0) || 1;
      let x = left;
      rowLabels.forEach((label, index) => {
        const value = rowValues[index];
        const tileWidth = width * (Math.max(0, value) / rowTotal);
        const w = Math.max(44, tileWidth - gap);
        const y = top + rowIndex * (rowHeight + 12);
        const color = colors[(rowIndex ? split : 0) + index] || '#2563eb';
        const labelText = String(label);
        const shortLabel = labelText.length > 18 ? `${labelText.slice(0, 17)}…` : labelText;
        inner += `<g><rect x="${x}" y="${y}" width="${w}" height="${rowHeight}" rx="8" fill="${esc(color)}" opacity=".92"><title>${esc(label)}: ${value}</title></rect>`;
        inner += text(shortLabel, x + 12, y + 28, 'native-chart-title');
        inner += text(`${value} jt`, x + 12, y + 50, 'native-chart-muted');
        inner += '</g>';
        x += tileWidth;
      });
    });
    inner += text('Luas kotak menunjukkan proporsi nilai', left, 316, 'native-chart-muted');
    mount.innerHTML = svg(inner, `Treemap ${chart.name || ''}`);
    return true;
  }

  function renderHeatmap(chart, mount) {
    const labels = chart?.chartjs?.data?.labels || [];
    const datasets = chart?.chartjs?.data?.datasets || [];
    if (labels.length < 2 || datasets.length < 2) return false;
    const left = 190, top = 36, cellW = 98, cellH = 54;
    let inner = '';
    labels.forEach((label, col) => { inner += text(label, left + col * cellW + cellW / 2, 22, 'native-chart-muted'); });
    datasets.forEach((dataset, row) => {
      const color = Array.isArray(dataset.backgroundColor) ? dataset.backgroundColor[0] : (dataset.backgroundColor || '#2563eb');
      inner += text(dataset.label || `Baris ${row + 1}`, 16, top + row * cellH + 32);
      (dataset.data || []).slice(0, labels.length).forEach((value, col) => {
        const x = left + col * cellW, y = top + row * cellH;
        const max = Math.max(...datasets.flatMap(item => (item.data || []).map(number)), 1);
        const opacity = .18 + (number(value) / max) * .78;
        inner += `<rect x="${x + 2}" y="${y}" width="${cellW - 4}" height="${cellH - 5}" rx="7" fill="${esc(color)}" opacity="${opacity.toFixed(2)}"><title>${esc(dataset.label || 'Nilai')} — ${esc(labels[col])}: ${number(value)}</title></rect>`;
        inner += text(number(value), x + cellW / 2, y + 30, 'native-chart-title');
      });
    });
    inner += text('Warna lebih pekat = volume transaksi lebih tinggi', left, 224, 'native-chart-muted');
    mount.innerHTML = svg(inner, `Heatmap ${chart.name || ''}`);
    return true;
  }

  function renderBoxPlot(chart, mount) {
    const labels = chart?.chartjs?.data?.labels || [];
    const datasets = chart?.chartjs?.data?.datasets || [];
    const medians = datasets[0]?.data || [];
    const maxima = datasets[1]?.data || [];
    const boxes = Array.isArray(chart.nativeData?.boxes) ? chart.nativeData.boxes : [];
    if (labels.length < 2 || medians.length !== labels.length || maxima.length !== labels.length) return false;
    const left = 76, bottom = 276, plotH = 224, plotW = 820;
    const maxValue = Math.max(...(boxes.length ? boxes.map((box) => number(box.max)) : maxima.map(number)), 1) + 1;
    const y = (value) => bottom - (number(value) / maxValue) * plotH;
    let inner = '';
    [0, .25, .5, .75, 1].forEach((tick) => {
      const value = Math.round(maxValue * tick);
      const yy = y(value);
      inner += `<line x1="${left}" y1="${yy}" x2="${left + plotW}" y2="${yy}" class="native-chart-grid"/>`;
      inner += text(value, 44, yy + 4, 'native-chart-muted');
    });
    const groupW = plotW / labels.length;
    labels.forEach((label, index) => {
      const median = number(boxes[index]?.median ?? medians[index]);
      const max = Math.max(median, number(boxes[index]?.max ?? maxima[index]));
      const min = number(boxes[index]?.min ?? Math.max(0, median - Math.max(1, median * .35)));
      const q1 = number(boxes[index]?.q1 ?? (min + (median - min) * .45));
      const q3 = number(boxes[index]?.q3 ?? (median + (max - median) * .55));
      const cx = left + groupW * index + groupW / 2;
      const boxW = Math.min(76, groupW * .42);
      const color = index % 2 ? '#60a5fa' : '#2563eb';
      inner += `<line x1="${cx}" y1="${y(max)}" x2="${cx}" y2="${y(min)}" stroke="#64748b" stroke-width="2"><title>${esc(label)}: ${min.toFixed(1)}–${max}</title></line>`;
      inner += `<line x1="${cx - boxW / 2}" y1="${y(max)}" x2="${cx + boxW / 2}" y2="${y(max)}" stroke="#64748b" stroke-width="2"/>`;
      inner += `<line x1="${cx - boxW / 2}" y1="${y(min)}" x2="${cx + boxW / 2}" y2="${y(min)}" stroke="#64748b" stroke-width="2"/>`;
      inner += `<rect x="${cx - boxW / 2}" y="${y(q3)}" width="${boxW}" height="${Math.max(8, y(q1) - y(q3))}" rx="6" fill="${color}" opacity=".88"><title>${esc(label)} — median ${median}</title></rect>`;
      inner += `<line x1="${cx - boxW / 2}" y1="${y(median)}" x2="${cx + boxW / 2}" y2="${y(median)}" stroke="#0f172a" stroke-width="3"/>`;
      inner += text(label, cx, bottom + 25, 'native-chart-muted').replace('text x=', 'text text-anchor="middle" x=');
    });
    inner += text('Ringkasan lima angka: minimum, Q1, median, Q3, maksimum', left, 326, 'native-chart-muted');
    mount.innerHTML = svg(inner, `Box Plot ${chart.name || ''}`);
    return true;
  }

  window.renderNativeChart = function (chart, mount) {
    if (!chart || !mount) return false;
    if (chart.id === 'treemap') return renderTreemap(chart, mount);
    if (chart.id === 'heatmap') return renderHeatmap(chart, mount);
    if (chart.id === 'box-plot') return renderBoxPlot(chart, mount);
    return false;
  };
})();
