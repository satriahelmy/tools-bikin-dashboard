const state = {
  allResources: [],
  filteredResources: [],
  selectedCategory: "Semua",
  selectedTags: new Set(),
  searchTerm: ""
};

const searchInputEl = document.getElementById("searchInput");
const categoryChipsEl = document.getElementById("categoryChips");
const tagChipsEl = document.getElementById("tagChips");
const resetFiltersBtnEl = document.getElementById("resetFiltersBtn");
const resourceGridEl = document.getElementById("resourceGrid");
const emptyStateEl = document.getElementById("emptyState");
const resourceCountEl = document.getElementById("resourceCount");
const toastEl = document.getElementById("toast");

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  window.setTimeout(() => toastEl.classList.remove("show"), 1800);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

const MAIN_CATEGORY_TAGS = new Set([
  "Tools & Software",
  "Belajar",
  "Dataset",
  "Desain & Warna",
  "Inspirasi",
  "Khusus Indonesia"
]);

function getBadgeClass(label) {
  if (label === "Gratis") return "bd-badge-green";
  if (label === "Freemium") return "bd-badge-orange";
  if (MAIN_CATEGORY_TAGS.has(label)) return "bd-badge-blue";
  return "bd-badge-gray";
}

function buildTagChips() {
  const tagsFromData = new Set();
  for (const resource of state.allResources) {
    if (!Array.isArray(resource.tags)) continue;
    for (const tag of resource.tags) {
      if (typeof tag === "string" && tag.trim()) {
        tagsFromData.add(tag.trim());
      }
    }
  }

  const preferredOrder = ["Gratis", "Freemium", "Berbayar", "Indonesia", "Tableau", "Power BI", "Python", "SQL"];
  const sortedTags = [...tagsFromData].sort((a, b) => {
    const ia = preferredOrder.indexOf(a);
    const ib = preferredOrder.indexOf(b);
    if (ia !== -1 && ib !== -1) return ia - ib;
    if (ia !== -1) return -1;
    if (ib !== -1) return 1;
    return a.localeCompare(b, "id");
  });

  if (!sortedTags.length) {
    tagChipsEl.innerHTML = '<p class="bd-hint">Belum ada tag tersedia.</p>';
    return;
  }

  tagChipsEl.innerHTML = sortedTags
    .map((tag) => `<button class="bd-chip" type="button" data-tag="${escapeHtml(tag)}">${escapeHtml(tag)}</button>`)
    .join("");
}

function syncCategoryChipActiveState() {
  const chips = categoryChipsEl.querySelectorAll("[data-category]");
  for (const chip of chips) {
    chip.classList.toggle("is-active", chip.dataset.category === state.selectedCategory);
  }
}

function syncTagChipActiveState() {
  const chips = tagChipsEl.querySelectorAll("[data-tag]");
  for (const chip of chips) {
    chip.classList.toggle("is-active", state.selectedTags.has(chip.dataset.tag));
  }
}

// Centralized filtering pipeline: search + category + tags (AND).
function applyFilters() {
  const search = state.searchTerm.trim().toLowerCase();

  state.filteredResources = state.allResources.filter((resource) => {
    const matchCategory =
      state.selectedCategory === "Semua" || resource.category === state.selectedCategory;

    const resourceTags = Array.isArray(resource.tags) ? resource.tags : [];
    const matchTags = [...state.selectedTags].every((tag) => resourceTags.includes(tag));

    const searchable = `${resource.name ?? ""} ${resource.description ?? ""} ${resource.note ?? ""}`.toLowerCase();
    const matchSearch = !search || searchable.includes(search);

    return matchCategory && matchTags && matchSearch;
  });

  renderResources(state.filteredResources);
  updateCount();
  syncCategoryChipActiveState();
  syncTagChipActiveState();
}

function renderResources(resources) {
  if (!resources.length) {
    resourceGridEl.innerHTML = "";
    emptyStateEl.hidden = false;
    return;
  }

  emptyStateEl.hidden = true;
  resourceGridEl.innerHTML = resources
    .map((resource) => {
      const safeName = escapeHtml(resource.name);
      const safeUrl = escapeHtml(resource.url);
      const safeDescription = escapeHtml(resource.description);
      const safeCategory = escapeHtml(resource.category);
      const safePrice = escapeHtml(resource.price);
      const tagsHtml = Array.isArray(resource.tags)
        ? resource.tags
            .map((tag) => `<span class="bd-badge ${getBadgeClass(tag)}">${escapeHtml(tag)}</span>`)
            .join("")
        : "";
      const noteHtml = resource.note
        ? `
          <div class="bd-curator-note">
            <span class="bd-label">Catatan kurator</span>
            <p class="bd-body">${escapeHtml(resource.note)}</p>
          </div>
        `
        : "";

      return `
        <article class="bd-card bd-resource-card">
          <div class="bd-card-body">
            <h3 class="bd-heading bd-resource-title">
              <a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${safeName}</a>
            </h3>
            <p class="bd-body">${safeDescription}</p>
            <div class="bd-resource-meta">
              <span class="bd-badge ${getBadgeClass(resource.category)}">${safeCategory}</span>
              <span class="bd-badge ${getBadgeClass(resource.price)}">${safePrice}</span>
              ${tagsHtml}
            </div>
            ${noteHtml}
          </div>
        </article>
      `;
    })
    .join("");
}

function updateCount() {
  resourceCountEl.textContent = `Menampilkan ${state.filteredResources.length} dari ${state.allResources.length} resource`;
}

function normalizeResourcesPayload(payload) {
  if (!payload || !Array.isArray(payload.resources)) {
    return [];
  }
  return payload.resources;
}

function loadResourcesViaXhr() {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "resources.json", true);
    xhr.overrideMimeType("application/json");

    xhr.onload = () => {
      const successStatus = xhr.status === 200 || xhr.status === 0;
      if (!successStatus) {
        reject(new Error("XHR gagal mengambil resources.json"));
        return;
      }

      try {
        const parsed = JSON.parse(xhr.responseText || "{}");
        resolve(normalizeResourcesPayload(parsed));
      } catch (error) {
        reject(new Error("XHR berhasil tetapi JSON tidak valid"));
      }
    };

    xhr.onerror = () => reject(new Error("XHR error saat load resources.json"));
    xhr.send();
  });
}

function attachEventHandlers() {
  searchInputEl.addEventListener("input", (event) => {
    state.searchTerm = event.target.value;
    applyFilters();
  });

  categoryChipsEl.addEventListener("click", (event) => {
    const chip = event.target.closest("[data-category]");
    if (!chip) return;
    state.selectedCategory = chip.dataset.category;
    applyFilters();
  });

  tagChipsEl.addEventListener("click", (event) => {
    const chip = event.target.closest("[data-tag]");
    if (!chip) return;
    const { tag } = chip.dataset;
    if (state.selectedTags.has(tag)) {
      state.selectedTags.delete(tag);
    } else {
      state.selectedTags.add(tag);
    }
    applyFilters();
  });

  resetFiltersBtnEl.addEventListener("click", () => {
    state.searchTerm = "";
    state.selectedCategory = "Semua";
    state.selectedTags.clear();
    searchInputEl.value = "";
    applyFilters();
    showToast("Filter direset.");
  });
}

async function loadResources() {
  try {
    let resources = [];

    try {
      const response = await fetch("resources.json", { cache: "no-store" });
      if (!response.ok) {
        throw new Error("Fetch response tidak OK.");
      }
      const data = await response.json();
      resources = normalizeResourcesPayload(data);
    } catch (fetchError) {
      // Fallback untuk environment preview/local file yang sering blok fetch JSON.
      resources = await loadResourcesViaXhr();
    }

    state.allResources = resources;
    state.filteredResources = [...state.allResources];
    buildTagChips();

    applyFilters();
  } catch (error) {
    state.allResources = [];
    state.filteredResources = [];
    buildTagChips();
    renderResources(state.filteredResources);
    updateCount();
    showToast("Gagal memuat resources.json. Jalankan lewat local server.");
  }
}

attachEventHandlers();
loadResources();
